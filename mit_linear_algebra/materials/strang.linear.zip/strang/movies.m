echo on
%  MATLAB has a "movie" to show how elimination reaches the
%  reduced echelon form R. You will see Gauss-Jordan elimination
%  changing the pivots to 1 and clearing out the pivot columns.
%
%  This file is called ratmovie in MATLAB 3.5 and Student MATLAB.
%  It is called rrefmovie in MATLAB 4.0 and 4.1.  Try it.
echo off

